#!/usr/bin/env python3
"""Refresh data.json for the OCE Comp Dashboard.

Usage (run from the repo root, stdlib only):

  python scripts/update_data.py --fetch
      Best-effort: pull OCE Power Rankings + Earnings from fortnitetracker.com
      and rebuild the players list. Writes nothing if the pages can't be read
      or the result looks wrong.

  python scripts/update_data.py --players-csv players.csv [--orgs-csv orgs.csv]
                                [--news-json news.json] [--events-json events.json]
                                [--spotlight-json spotlight.json]
      Manual mode: replace those sections from files you provide.

players.csv columns: name,team,country,pr,earnings[,earn_rank]
   (earn_rank is worked out from earnings if left out)
orgs.csv columns:    name,country,roster,pr,earnings
news.json:           [{"title": "...", "date": "13 Nov 2026", "url": "https://..."}]
events.json:         [["Name","Type","Window","2026-11-21T07:00Z","eventId"], ...]
spotlight.json:      {"events": 618, "items": [["Title","Detail"], ...]}

Safety: sections are only replaced if they pass basic checks, and data.json is
only rewritten when something actually changed.
"""
import argparse, csv, datetime, json, re, sys, urllib.request
from html.parser import HTMLParser
from pathlib import Path

DATA = Path(__file__).resolve().parent.parent / "data.json"
BASE = "https://fortnitetracker.com/events/"
UA = "Mozilla/5.0 (compatible; OCE-Comp-Dashboard-updater)"


def num(v):
    v = re.sub(r"[^0-9.\-]", "", str(v or ""))
    if v in ("", "-", "."):
        raise ValueError("not a number")
    return int(round(float(v)))


def pick(row, *names):
    low = {k.strip().lower(): v for k, v in row.items() if k}
    for n in names:
        if n in low and low[n] not in (None, ""):
            return low[n]
    return ""


def read_players_csv(path):
    rows = []
    with open(path, newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            name = pick(r, "name", "player").strip()
            if not name:
                continue
            er = pick(r, "earn_rank", "earnrank", "earnings_rank")
            rows.append({
                "n": name,
                "t": pick(r, "team", "org", "organisation").strip(),
                "c": pick(r, "country").strip(),
                "p": num(pick(r, "pr", "points", "pr_points")),
                "e": num(pick(r, "earnings", "earned") or 0),
                "er": num(er) if er else None,
            })
    return finish_players(rows)


def finish_players(rows):
    rows.sort(key=lambda x: -x["p"])
    if any(x["er"] is None for x in rows):
        by_e = sorted(rows, key=lambda x: -x["e"])
        rank = {id(x): i + 1 for i, x in enumerate(by_e)}
        for x in rows:
            if x["er"] is None:
                x["er"] = rank[id(x)]
    for i, x in enumerate(rows):
        x["r"] = i + 1
    return [{"r": x["r"], "n": x["n"], "t": x["t"], "c": x["c"], "p": x["p"], "e": x["e"], "er": x["er"]} for x in rows]


def read_orgs_csv(path):
    rows = []
    with open(path, newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            name = pick(r, "name", "org", "organisation").strip()
            if not name:
                continue
            rows.append({"n": name, "c": pick(r, "country").strip(), "m": pick(r, "roster", "members").strip(),
                         "p": num(pick(r, "pr", "points", "pr_points")), "e": num(pick(r, "earnings") or 0)})
    rows.sort(key=lambda x: -x["p"])
    for i, x in enumerate(rows):
        x["r"] = i + 1
    return [{"r": x["r"], "n": x["n"], "c": x["c"], "m": x["m"], "p": x["p"], "e": x["e"]} for x in rows]


# ---------------------------------------------------------------- fetch mode
class Tables(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tables, self._t, self._r, self._c, self._in = [], None, None, None, False

    def handle_starttag(self, tag, attrs):
        if tag == "table":
            self._t = []
        elif tag == "tr" and self._t is not None:
            self._r = []
        elif tag in ("td", "th") and self._r is not None:
            self._c, self._in = [], True

    def handle_data(self, d):
        if self._in:
            self._c.append(d)

    def handle_endtag(self, tag):
        if tag in ("td", "th") and self._r is not None and self._c is not None:
            self._r.append(" ".join("".join(self._c).split()))
            self._c, self._in = None, False
        elif tag == "tr" and self._t is not None and self._r is not None:
            if self._r:
                self._t.append(self._r)
            self._r = None
        elif tag == "table" and self._t is not None:
            self.tables.append(self._t)
            self._t = None


def get_table(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "text/html"})
    with urllib.request.urlopen(req, timeout=30) as r:
        html = r.read().decode("utf-8", "replace")
    p = Tables()
    p.feed(html)
    if not p.tables:
        raise RuntimeError("no table found at " + url + " (page may be JavaScript-rendered or blocked)")
    return max(p.tables, key=len)


def col(header, *keys):
    for i, h in enumerate(header):
        if any(k in h.lower() for k in keys):
            return i
    raise RuntimeError("column %s not found in header %s" % (keys, header))


def fetch_players():
    pr = get_table(BASE + "powerrankings?platform=pc&region=OCE")
    h = pr[0]
    ci_name, ci_pts = col(h, "player", "name"), col(h, "point", "pr")
    ci_team = next((i for i, x in enumerate(h) if "team" in x.lower() or "org" in x.lower()), None)
    ci_earn = next((i for i, x in enumerate(h) if "earn" in x.lower()), None)
    rows = []
    for r in pr[1:]:
        try:
            rows.append({"n": r[ci_name], "t": r[ci_team] if ci_team is not None else "", "c": "",
                         "p": num(r[ci_pts]), "e": num(r[ci_earn]) if ci_earn is not None else 0, "er": None})
        except (ValueError, IndexError):
            continue
    try:  # earnings table gives the earnings rank
        er = get_table(BASE + "earnings?platform=pc&region=OCE")
        eh = er[0]
        en, ee = col(eh, "player", "name"), col(eh, "earn")
        order = {}
        for i, r in enumerate(er[1:]):
            order.setdefault(r[en].lower(), (i + 1, num(r[ee])))
        for x in rows:
            if x["n"].lower() in order:
                x["er"], x["e"] = order[x["n"].lower()]
    except Exception as e:
        print("earnings page skipped:", e, file=sys.stderr)
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fetch", action="store_true")
    for k in ("players-csv", "orgs-csv", "news-json", "events-json", "spotlight-json"):
        ap.add_argument("--" + k)
    a = ap.parse_args()

    d = json.loads(DATA.read_text(encoding="utf-8"))
    before = json.dumps({k: v for k, v in d.items() if k != "updated"}, sort_keys=True)
    old_players = {x["n"]: x for x in d.get("players", [])}

    if a.fetch:
        try:
            rows = fetch_players()
            # fall back to the old country / earnings-rank values where the page lacks them
            for x in rows:
                o = old_players.get(x["n"])
                if o:
                    x["c"] = x["c"] or o.get("c", "")
                    if x["er"] is None:
                        x["er"] = o.get("er")
            for i, x in enumerate(rows):
                if x["er"] is None:
                    x["er"] = 9999
            players = finish_players(rows)[:100]
            if len(players) < 50:
                raise RuntimeError("only %d player rows parsed, refusing to overwrite" % len(players))
            d["players"] = players
        except Exception as e:
            print("FETCH FAILED, data.json left unchanged:", e, file=sys.stderr)
            return 2
    if a.players_csv:
        d["players"] = read_players_csv(a.players_csv)
    if a.orgs_csv:
        d["orgs"] = read_orgs_csv(a.orgs_csv)
    if a.news_json:
        news = json.loads(Path(a.news_json).read_text(encoding="utf-8"))
        d["news"] = [n for n in news if str(n.get("url", "")).startswith("https://") and n.get("title")]
    if a.events_json:
        d["events"] = json.loads(Path(a.events_json).read_text(encoding="utf-8"))
    if a.spotlight_json:
        d["spotlight"] = json.loads(Path(a.spotlight_json).read_text(encoding="utf-8"))

    if len(d["players"]) < 50 or len(d["orgs"]) < 10:
        print("Refusing to write: too few players/orgs.", file=sys.stderr)
        return 3
    after = json.dumps({k: v for k, v in d.items() if k != "updated"}, sort_keys=True)
    if before == after:
        print("No changes.")
        return 0
    d["updated"] = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d")
    DATA.write_text(json.dumps(d, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    print("data.json updated:", d["updated"], "-", len(d["players"]), "players")
    return 0


if __name__ == "__main__":
    sys.exit(main())
