# OCE Comp Dashboard

`index.html` is the dashboard. It loads `data.json` (players, orgs, events, news, spotlight, "updated" date) every time it opens. If `data.json` can't be loaded, it falls back to the data baked into the page.

## Hosting with auto-updates (GitHub Pages)

1. Create a GitHub repo and upload everything in this folder, keeping the structure (including `.github/workflows/update.yml`).
2. Repo Settings > Pages > deploy from the `main` branch, root folder. Your dashboard will be at `https://<you>.github.io/<repo>/`.
3. Repo Settings > Actions > General > Workflow permissions > "Read and write permissions".
4. Actions tab > "Update OCE data" > Run workflow, to test it once.

The workflow runs about 3h15m after each event session starts (times are generated from the schedule in `data.json`) and once a day at 6:00am Brisbane. It runs `scripts/update_data.py --fetch`.

## Important: the fetch is best-effort

`--fetch` reads the OCE Power Rankings and Earnings tables from fortnitetracker.com. It was written without being able to reach the site, so it is untested against the real pages. Tracker may block it or render the tables with JavaScript. If that happens the run prints "FETCH FAILED", leaves `data.json` untouched, and the dashboard just keeps showing the last good data. Check the Actions log after the first run; if it fails, the parsing in `fetch_players()` needs adjusting to what the page really returns.

## Manual update (always works)

Put the new numbers in files and run, from this folder:

```
python scripts/update_data.py --players-csv players.csv --orgs-csv orgs.csv --news-json news.json
```

File formats are described at the top of `scripts/update_data.py`. Commit the changed `data.json` and the site updates. You can also edit `data.json` by hand.

## When the event schedule changes

Edit the `events` list in `data.json` (or pass `--events-json`). The page picks it up straight away. To also move the workflow's run times, adjust the `cron` lines in `.github/workflows/update.yml`; the daily run covers it in the meantime.
